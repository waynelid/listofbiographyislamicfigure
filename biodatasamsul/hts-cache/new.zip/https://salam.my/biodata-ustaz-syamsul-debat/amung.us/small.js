<!DOCTYPE html>
<!--[if IE 8]>
<html class="no-js lt-ie10 lt-ie9" id="ie8" lang="en-US"><![endif]-->
<!--[if IE 9]>
<html class="no-js lt-ie10" id="ie9" lang="en-US"><![endif]-->
<!--[if !IE]><!-->
<html class="no-js" lang="en-US"><!--<![endif]-->
<head>
	<meta charset="UTF-8"/>
	<link rel="profile" href="http://gmpg.org/xfn/11"/>
	<link rel="pingback" href="https://salam.my/xmlrpc.php"/>

	<title>Page not found &#8211; Salam.my</title>

<meta name="viewport" content="initial-scale=1.0, width=device-width" />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Salam.my &raquo; Feed" href="https://salam.my/feed/" />
<link rel="alternate" type="application/rss+xml" title="Salam.my &raquo; Comments Feed" href="https://salam.my/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/salam.my\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.6.13"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='https://salam.my/wp-includes/css/dist/block-library/style.min.css?ver=5.6.13' type='text/css' media='all' />
<link rel='stylesheet' id='quads-style-css-css'  href='https://salam.my/wp-content/plugins/quick-adsense-reloaded/includes/gutenberg/dist/blocks.style.build.css?ver=2.0.17.1' type='text/css' media='all' />
<link rel='stylesheet' id='mashsb-styles-css'  href='https://salam.my/wp-content/plugins/mashsharer/assets/css/mashsb.min.css?ver=3.7.8' type='text/css' media='all' />
<style id='mashsb-styles-inline-css' type='text/css'>
.mashsb-count {color:#cccccc;}@media only screen and (min-width:568px){.mashsb-buttons a {min-width: 177px;}}
</style>
<link rel='stylesheet' id='wyr-main-css'  href='https://salam.my/wp-content/plugins/whats-your-reaction/css/main.min.css?ver=1.0' type='text/css' media='all' />
<link rel='stylesheet' id='wordpress-popular-posts-css-css'  href='https://salam.my/wp-content/plugins/wordpress-popular-posts/assets/css/wpp.css?ver=5.2.4' type='text/css' media='all' />
<link rel='stylesheet' id='g1-original-css'  href='https://salam.my/wp-content/themes/bimber/css/original/all.css?ver=3.4' type='text/css' media='all' />
<link rel='stylesheet' id='bimber-google-fonts-css'  href='//fonts.googleapis.com/css?family=Roboto%3A400%2C300%2C500%2C600%2C700%2C900%7CPoppins%3A400%2C300%2C500%2C600%2C700&#038;subset=latin%2Clatin-ext&#038;ver=3.4' type='text/css' media='all' />
<link rel='stylesheet' id='bimber-dynamic-style-css'  href='http://salam.my/wp-content/uploads/dynamic-style.css?respondjs=no&#038;ver=3.4' type='text/css' media='all' />
<style id='quads-styles-inline-css' type='text/css'>
.quads-ad-label { font-size: 12px; text-align: center; color: #333;}
</style>
<script type='text/javascript' src='https://salam.my/wp-includes/js/jquery/jquery.min.js?ver=3.5.1' id='jquery-core-js'></script>
<script type='text/javascript' src='https://salam.my/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' id='mashsb-js-extra'>
/* <![CDATA[ */
var mashsb = {"shares":"0","round_shares":"1","animate_shares":"0","dynamic_buttons":"0","share_url":"https:\/\/salam.my\/pastor-kristian-ini-hancurkan-patung-mary-ini-sebabnya\/","title":"Pastor+Kristian+Ini+Hancurkan+Patung+Mary.+Ini+Sebabnya","image":"https:\/\/salam.my\/wp-content\/uploads\/2020\/10\/pastor-patung-mary.png","desc":"Salam.my - Viral sebuah video seorang pastor kristian memecahkan sebuah patung Mary selepas berdebat tentangnya. Ini sebabnya.\n\n\n\n\n\n\n\nVideo berdurasi lebih 8 minit ini telah mendapat perhatian ramai netizen sehingga lebih 40k responses dan 10k komen.\n\n\n\nCaption video \u2026","hashtag":"","subscribe":"content","subscribe_url":"","activestatus":"1","singular":"0","twitter_popup":"1","refresh":"0","nonce":"1a5bccafa7","postid":"","servertime":"1716730671","ajaxurl":"https:\/\/salam.my\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='https://salam.my/wp-content/plugins/mashsharer/assets/js/mashsb.min.js?ver=3.7.8' id='mashsb-js'></script>
<script type='application/json' id='wpp-json'>
{"sampling_active":0,"sampling_rate":100,"ajax_url":"https:\/\/salam.my\/wp-json\/wordpress-popular-posts\/v1\/popular-posts","ID":0,"token":"c3e6147b0a","lang":0,"debug":0}
</script>
<script type='text/javascript' src='https://salam.my/wp-content/plugins/wordpress-popular-posts/assets/js/wpp.min.js?ver=5.2.4' id='wpp-js-js'></script>
<script type='text/javascript' src='https://salam.my/wp-content/themes/bimber/js/modernizr/modernizr-custom.min.js?ver=3.3.0' id='modernizr-js'></script>
<link rel="https://api.w.org/" href="https://salam.my/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://salam.my/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://salam.my/wp-includes/wlwmanifest.xml" /> 
<script type="text/javascript" src="https://salam.my/wp-content/plugins/quick-adsense-reloaded/assets/js/ads.js"></script><script type='text/javascript'>document.cookie = 'quads_browser_width='+screen.width;</script><link rel="icon" href="https://salam.my/wp-content/uploads/2017/01/logo-150x150.png" sizes="32x32" />
<link rel="icon" href="https://salam.my/wp-content/uploads/2017/01/logo.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://salam.my/wp-content/uploads/2017/01/logo.png" />
<meta name="msapplication-TileImage" content="https://salam.my/wp-content/uploads/2017/01/logo.png" />

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-8923034957371852",
    enable_page_level_ads: true
  });
</script>
</head>

<body class="error404 g1-layout-stretched g1-hoverable" itemscope itemtype="http://schema.org/WebPage">

<div class="g1-body-inner">

	<div id="page">
		

		

		
		<div class="g1-header g1-row g1-row-layout-page">
			<div class="g1-row-inner">
				<div class="g1-column">
					
<div class="g1-id">
				<p class="g1-mega g1-mega-2nd site-title">
			
			<a class="g1-logo-wrapper"
			   href="https://salam.my/" rel="home">
									<img class="g1-logo g1-logo-default" width="165" height="72" src="http://salam.my/wp-content/uploads/2018/02/bloglogo.png"  alt="Salam.my" />							</a>

				</p>

			<p class="g1-delta g1-delta-3rd site-description">Sebarkan Salam</p>
	</div>
						
	<nav class="g1-quick-nav g1-quick-nav-short">
		<ul class="g1-quick-nav-menu">
			
			
									<li class="menu-item menu-item-type-g1-latest ">
						<a href="https://salam.my">
							<span class="entry-flag entry-flag-latest"></span>
							Terkini						</a>
					</li>
				
									<li class="menu-item menu-item-type-g1-popular ">
						<a href="https://salam.my/popular/">
							<span class="entry-flag entry-flag-popular"></span>
							Popular						</a>
					</li>
				
									<li class="menu-item menu-item-type-g1-hot ">
						<a href="https://salam.my/hot/">
							<span class="entry-flag entry-flag-hot"></span>
							Hot						</a>
					</li>
				
									<li class="menu-item menu-item-type-g1-trending ">
						<a href="https://salam.my/trending/">
							<span class="entry-flag entry-flag-trending"></span>
							Trending						</a>
					</li>
				
					</ul>
	</nav>
				</div>
			</div>
			<div class="g1-row-background"></div>
		</div>

	<div class="g1-sticky-top-wrapper">

		<div class="g1-row g1-row-layout-page g1-navbar">
			<div class="g1-row-inner">
				<div class="g1-column g1-dropable">
											<a class="g1-hamburger g1-hamburger-show" href="">
							<span class="g1-hamburger-icon"></span>
							<span class="g1-hamburger-label">Menu</span>
						</a>
					
										
					<!-- BEGIN .g1-primary-nav -->
					<nav id="g1-primary-nav" class="g1-primary-nav"><ul id="g1-primary-nav-menu" class="g1-primary-nav-menu"><li id="menu-item-45" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-45"><a href="https://salam.my/category/nur/">Nur</a></li>
<li id="menu-item-46" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-46"><a href="https://salam.my/category/inspirasi/">Inspirasi</a></li>
<li id="menu-item-62" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-62"><a href="https://salam.my/category/quran/">Quran</a></li>
<li id="menu-item-63" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-63"><a href="https://salam.my/category/sunnah/">Sunnah</a></li>
<li id="menu-item-143" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-143"><a href="https://salam.my/category/dunia-islam/">Dunia Islam</a></li>
<li id="menu-item-144" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-144"><a href="https://salam.my/category/politik/">Politik</a></li>
<li id="menu-item-145" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-145"><a href="https://salam.my/category/gaya-hidup/">Gaya Hidup</a></li>
<li id="menu-item-168" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-168"><a href="https://salam.my/category/ilmu/">Ilmu</a></li>
<li id="menu-item-169" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-169"><a href="https://salam.my/category/sahabat/">Sahabat</a></li>
<li id="menu-item-170" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-170"><a href="https://salam.my/category/hadith/">Hadith</a></li>
</ul></nav>					<!-- END .g1-primary-nav -->

					

<!-- BEGIN .g1-user-nav -->
<!-- END .g1-user-nav -->

						<div class="g1-drop g1-drop-before g1-drop-the-search">
		<a class="g1-drop-toggle" href="#">
			<i class="bimber-icon bimber-icon-search"></i>Search			<span class="g1-drop-toggle-arrow"></span>
		</a>
		<div class="g1-drop-content">
			

<div role="search">
	<form method="get"
	      class="g1-searchform-tpl-default g1-form-s search-form"
	      action="https://salam.my/">
		<label>
			<span class="screen-reader-text">Search for:</span>
			<input type="search" class="search-field"
			       placeholder="Search &hellip;"
			       value="" name="s"
			       title="Search for:"/>
		</label>
		<input type="submit" class="search-submit"
		       value="Search"/>
	</form>
</div>
		</div>
	</div>
									</div><!-- .g1-column -->

			</div>
		</div>
	</div>

		



	<div id="primary" class="g1-primary-max">
		<div id="content" role="main">

			<article id="post-0">
				<header class="g1-row g1-row-layout-page entry-header entry-header-row">
					<div class="g1-row-inner">
						<div class="g1-column">

							<h1 class="g1-alpha g1-alpha-2nd entry-title">Ooops, sorry! We couldn&#039;t find it</h1>
							<h2 class="g1-delta g1-delta-3rd entry-subtitle">You have requested a page or file which doesn&#039;t exist</h2>

						</div><!-- .g1-column -->
					</div>
					<div class="g1-row-background">
					</div>
				</header><!-- .g1-row -->

				<div class="g1-row g1-row-layout-page g1-row-padding-l entry-content">
					<div class="g1-row-inner">

						<div class="g1-column g1-column-1of3">
							<div class="g1-column-inner">
								<i class="bimber-search g1-404-icon"></i>
								<h2 class="g1-gamma g1-gamma-2nd">Search Our Website</h2>
								

<div role="search">
	<form method="get"
	      class="g1-searchform-tpl-default g1-form-s search-form"
	      action="https://salam.my/">
		<label>
			<span class="screen-reader-text">Search for:</span>
			<input type="search" class="search-field"
			       placeholder="Search &hellip;"
			       value="" name="s"
			       title="Search for:"/>
		</label>
		<input type="submit" class="search-submit"
		       value="Search"/>
	</form>
</div>
							</div>
						</div><!-- .g1-column -->

						<div class="g1-column g1-column-1of3">
							<div class="g1-column-inner">
								<i class="bimber-mail g1-404-icon"></i>
								<h2 class="g1-gamma g1-gamma-2nd">Report a Problem</h2>
								<p>Please write some descriptive information about your problem, and email our <a href="mailto:%6duh&#097;im%69%6e&#064;m&#117;&#104;&#097;im%2ein">webmaster</a>.</p>
							</div>
						</div><!-- .g1-column -->

						<div class="g1-column g1-column-1of3">
							<div class="g1-column-inner">
								<i class="bimber-home g1-404-icon"></i>
								<h2 class="g1-gamma g1-gamma-2nd">Back to the Homepage</h2>
								<p>You can also <a href="https://salam.my">go back to the homepage</a> and start browsing from there.</p>
							</div>
						</div>
					</div>

					<div class="g1-row-background">
					</div>
				</div><!-- .entry-content -->

			</article><!-- #post-0 -->

		</div><!-- #content -->
	</div><!-- #primary -->



<div class="g1-row g1-row-layout-page g1-footer">
	<div class="g1-row-inner">
		<div class="g1-column">

			<p class="g1-footer-text">© Salam.my | Sebarkan salam</p>

			
			

<script id="_waumtp">var _wau = _wau || []; _wau.push(["small", "mxprmos6ri93", "mtp"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="//widgets.amung.us/small.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script>

		</div><!-- .g1-column -->
	</div>
	<div class="g1-row-background">
	</div>
</div><!-- .g1-row -->

	<a href="#page" class="g1-back-to-top">Back to Top</a>

</div><!-- #page -->

<div class="g1-canvas-overlay"></div>

</div><!-- .g1-body-inner -->
<div id="g1-breakpoint-desktop"></div>
<div class="g1-canvas g1-canvas-global">
	<a class="g1-canvas-toggle" href="#"></a>
	<div class="g1-canvas-content">
	</div>
</div>
<script type="text/javascript">
   if(typeof quadsOptions !== 'undefined' && typeof wpquads_adblocker_check_2 
  === 'undefined' && quadsOptions.quadsChoice == 'ad_blocker_message'){

  var addEvent1 = function (obj, type, fn) {
      if (obj.addEventListener)
          obj.addEventListener(type, fn, false);
      else if (obj.attachEvent)
          obj.attachEvent('on' + type, function () {
              return fn.call(obj, window.event);
          });
  };
   addEvent1(window, 'load', function () {
      if (typeof wpquads_adblocker_check_2 === "undefined" || wpquads_adblocker_check_2 === false) {
          highlight_adblocked_ads();
      }
  });

   function highlight_adblocked_ads() {
      try {
          var ad_wrappers = document.querySelectorAll('div[id^="quads-ad"]')
      } catch (e) {
          return;
      }

      for (i = 0; i < ad_wrappers.length; i++) {
          ad_wrappers[i].className += ' quads-highlight-adblocked';
          ad_wrappers[i].className = ad_wrappers[i].className.replace('quads-location', '');
          ad_wrappers[i].setAttribute('style', 'display:block !important');
      }
  }
 }

(function() {
//Adblocker Notice Script Starts Here
var curr_url = window.location.href;
var red_ulr = localStorage.getItem('curr');
var modal = document.getElementById("quads-myModal");
var quadsAllowedCookie =  quadsgetCookie('quadsAllowedCookie');

if(typeof quadsOptions !== 'undefined' && typeof wpquads_adblocker_check_2 
  === 'undefined' ){

  if(quadsAllowedCookie!=quadsOptions.allow_cookies){
    quadssetCookie('quadsCookie', '', -1, '/');
    quadssetCookie('quadsAllowedCookie', quadsOptions.allow_cookies, 1, '/');
  }

  if(quadsOptions.allow_cookies == 2){
    if( quadsOptions.quadsChoice == 'bar' || quadsOptions.quadsChoice == 'popup'){
        modal.style.display = "block";
        quadssetCookie('quadsCookie', '', -1, '/');
    }
    
    if(quadsOptions.quadsChoice == 'page_redirect' && quadsOptions.page_redirect !="undefined"){
        if(red_ulr==null || curr_url!=quadsOptions.page_redirect){
        window.location = quadsOptions.page_redirect;
        localStorage.setItem('curr',quadsOptions.page_redirect);
      }
    }
  }else{
    var adsCookie = quadsgetCookie('quadsCookie');
    if(adsCookie==false) {
      if( quadsOptions.quadsChoice == 'bar' || quadsOptions.quadsChoice == 'popup'){
          modal.style.display = "block";
      }
      if(quadsOptions.quadsChoice == 'page_redirect' && quadsOptions.page_redirect !="undefined"){
        window.location = quadsOptions.page_redirect;
        quadssetCookie('quadsCookie', true, 1, '/');
      }
    }else{
      modal.style.display = "none";
    }
  }
}



var span = document.getElementsByClassName("quads-cls-notice")[0];
if(span){
  span.onclick = function() {
    modal.style.display = "none";
    document.cookie = "quads_prompt_close="+new Date();
    quadssetCookie('quadsCookie', 'true', 1, '/');
  }
}

window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
    document.cookie = "quads_prompt_close="+new Date();
    quadssetCookie('quadsCookie', 'true', 1, '/');
  }
}
})();
function quadsgetCookie(cname){
    var name = cname + '=';
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i].trim();
        if (c.indexOf(name) === 0) {
            return c.substring(name.length, c.length);
        }
    }
    return false;
}
function quadssetCookie(cname, cvalue, exdays, path){
  var d = new Date();
  d.setTime(d.getTime() + (exdays*24*60*60*1000));
  var expires = "expires="+ d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}
//Adblocker Notice Script Ends Here
</script>

<script type='text/javascript' id='wyr-front-js-extra'>
/* <![CDATA[ */
var wyr_front_config = "{\"ajax_url\":\"https:\\\/\\\/salam.my\\\/wp-admin\\\/admin-ajax.php\"}";
/* ]]> */
</script>
<script type='text/javascript' src='https://salam.my/wp-content/plugins/whats-your-reaction/js/front.js?ver=1.0' id='wyr-front-js'></script>
<script type='text/javascript' id='wpzerospam-js-extra'>
/* <![CDATA[ */
var wpzerospam = {"key":"#l(cotv4OAD9v9dLPxAV5)vSPQHTiSJTsT9L$i$*Z9eckvkPiVc7IQ)HX59wd$wy"};
/* ]]> */
</script>
<script type='text/javascript' src='https://salam.my/wp-content/plugins/zero-spam/assets/js/wpzerospam.js?ver=4.10.2' id='wpzerospam-js'></script>
<script type='text/javascript' src='https://salam.my/wp-content/themes/bimber/js/stickyfill/stickyfill.min.js?ver=1.3.1' id='stickyfill-js'></script>
<script type='text/javascript' src='https://salam.my/wp-content/themes/bimber/js/jquery.placeholder/placeholders.jquery.min.js?ver=4.0.1' id='jquery-placeholder-js'></script>
<script type='text/javascript' src='https://salam.my/wp-content/themes/bimber/js/jquery.timeago/jquery.timeago.js?ver=1.5.2' id='jquery-timeago-js'></script>
<script type='text/javascript' src='https://salam.my/wp-content/themes/bimber/js/jquery.timeago/locales/jquery.timeago.en.js' id='jquery-timeago-en-js'></script>
<script type='text/javascript' src='https://salam.my/wp-content/themes/bimber/js/matchMedia/matchMedia.js' id='match-media-js'></script>
<script type='text/javascript' src='https://salam.my/wp-content/themes/bimber/js/matchMedia/matchMedia.addListener.js' id='match-media-add-listener-js'></script>
<script type='text/javascript' src='https://salam.my/wp-content/themes/bimber/js/picturefill/picturefill.min.js?ver=2.3.1' id='picturefill-js'></script>
<script type='text/javascript' src='https://salam.my/wp-content/themes/bimber/js/jquery.waypoints/jquery.waypoints.min.js?ver=4.0.0' id='jquery-waypoints-js'></script>
<script type='text/javascript' src='https://salam.my/wp-content/themes/bimber/js/libgif/libgif.js' id='libgif-js'></script>
<script type='text/javascript' src='https://salam.my/wp-content/themes/bimber/js/enquire/enquire.min.js?ver=2.1.2' id='enquire-js'></script>
<script type='text/javascript' id='bimber-front-js-extra'>
/* <![CDATA[ */
var bimber_front_config = "{\"ajax_url\":\"https:\\\/\\\/salam.my\\\/wp-admin\\\/admin-ajax.php\",\"timeago\":\"on\",\"sharebar\":\"on\",\"i18n\":{\"newsletter\":{\"subscribe_mail_subject_tpl\":\"Check out this great article: %subject%\"},\"bp_profile_nav\":{\"more_link\":\"More\"}}}";
/* ]]> */
</script>
<script type='text/javascript' src='https://salam.my/wp-content/themes/bimber/js/front.js?ver=3.4' id='bimber-front-js'></script>
<script type='text/javascript' src='https://salam.my/wp-content/themes/bimber/js/menu.js?ver=3.4' id='bimber-menu-js'></script>
<script type='text/javascript' src='https://salam.my/wp-includes/js/wp-embed.min.js?ver=5.6.13' id='wp-embed-js'></script>
</body>
</html>
